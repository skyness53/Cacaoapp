package com.tesis.app_cacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
