import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:app_cacao/core/constants/supabase_config.dart';
import 'package:app_cacao/core/services/sqlite_service.dart';
import 'package:app_cacao/main.dart';

// Pruebas R1–R4 — Rendimiento (en dispositivo real)
// Miden tiempos de respuesta críticos para la experiencia de usuario,
// estableciendo umbrales máximos aceptables para cada operación.
//
// Requisito: dispositivo Android físico o emulador.
// Ejecutar con:
//   flutter test integration_test/rendimiento_test.dart

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    try {
      Supabase.instance.client;
    } catch (_) {
      await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
    }
  });

  // ── Prueba R1 ────────────────────────────────────────────────────────────────
  // Mide el tiempo desde que se lanza el widget raíz hasta que la UI queda
  // estable. Umbral: 5 000 ms (incluye inicialización de cámara en dispositivo).
  testWidgets('R1: la app alcanza estado estable en menos de 5 segundos',
      (tester) async {
    final cronometro = Stopwatch()..start();

    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 3));

    cronometro.stop();

    expect(
      cronometro.elapsedMilliseconds,
      lessThan(5000),
      reason: 'Inicio tomó ${cronometro.elapsedMilliseconds} ms (límite: 5 000 ms)',
    );
  });

  // ── Prueba R2 ────────────────────────────────────────────────────────────────
  // Mide el tiempo que tarda la animación de cambio entre las pestañas
  // Detectar e Historial. Umbral: 1 000 ms.
  testWidgets('R2: cambio de pestaña completa la animación en menos de 1 segundo',
      (tester) async {
    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 3));

    final cronometro = Stopwatch()..start();
    await tester.tap(find.byIcon(Icons.history_outlined));
    await tester.pumpAndSettle();
    cronometro.stop();

    expect(
      cronometro.elapsedMilliseconds,
      lessThan(1000),
      reason: 'Cambio de pestaña tomó ${cronometro.elapsedMilliseconds} ms (límite: 1 000 ms)',
    );
  });

  // ── Prueba R3 ────────────────────────────────────────────────────────────────
  // Mide el tiempo de inicialización de la base de datos SQLite en el dispositivo.
  // Umbral: 2 000 ms (apertura de archivo + creación de tablas en primer uso).
  test('R3: SQLiteService se inicializa en menos de 2 segundos', () async {
    final sqlite = SQLiteService();
    final cronometro = Stopwatch()..start();
    await sqlite.inicializar();
    cronometro.stop();
    sqlite.dispose();

    expect(
      cronometro.elapsedMilliseconds,
      lessThan(2000),
      reason: 'Inicialización SQLite tomó ${cronometro.elapsedMilliseconds} ms (límite: 2 000 ms)',
    );
  });

  // ── Prueba R4 ────────────────────────────────────────────────────────────────
  // Mide el tiempo de 20 inserciones consecutivas en la tabla historial,
  // incluyendo la limpieza automática al superar el límite de 20 registros.
  // Umbral: 3 000 ms.
  test('R4: 20 inserciones en historial completan en menos de 3 segundos', () async {
    final sqlite = SQLiteService();
    await sqlite.inicializar();

    final cronometro = Stopwatch()..start();
    for (int i = 0; i < 20; i++) {
      await sqlite.guardarEnHistorial(HistorialRegistro(
        imagenPath: '/img/perf_$i.jpg',
        etiqueta:   'Sana',
        confianza:  0.90,
        estaSana:   true,
        timestamp:  DateTime.now().millisecondsSinceEpoch + i,
      ));
    }
    cronometro.stop();
    sqlite.dispose();

    expect(
      cronometro.elapsedMilliseconds,
      lessThan(3000),
      reason: '20 inserciones tomaron ${cronometro.elapsedMilliseconds} ms (límite: 3 000 ms)',
    );
  });
}
