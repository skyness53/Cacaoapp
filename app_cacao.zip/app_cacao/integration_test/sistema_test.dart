import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:app_cacao/core/constants/supabase_config.dart';
import 'package:app_cacao/main.dart';

// Pruebas S1–S4 — Sistema (extremo a extremo en dispositivo real)
// Validan el comportamiento completo de la aplicación tal como lo
// experimenta el usuario final: navegación, estados de UI y flujo entre pantallas.
//
// Requisito: dispositivo Android físico o emulador con soporte de cámara.
// Ejecutar con:
//   flutter test integration_test/sistema_test.dart

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    try {
      Supabase.instance.client;
    } catch (_) {
      await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
    }
  });

  // ── Prueba S1 ────────────────────────────────────────────────────────────────
  // Verifica que al iniciar la app el tab activo es "Detectar" (índice 0).
  testWidgets('S1: la app inicia en la pestaña Detectar por defecto',
      (tester) async {
    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 3));

    expect(find.byType(BottomNavigationBar), findsOneWidget);

    final navBar = tester.widget<BottomNavigationBar>(
      find.byType(BottomNavigationBar),
    );
    expect(navBar.currentIndex, 0,
        reason: 'La app debe abrir en la pestaña Detectar (índice 0)');
  });

  // ── Prueba S2 ────────────────────────────────────────────────────────────────
  // Verifica que la barra de navegación tiene exactamente dos pestañas con las
  // etiquetas correctas ("Detectar" e "Historial").
  testWidgets('S2: la barra de navegación tiene dos pestañas con etiquetas correctas',
      (tester) async {
    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 2));

    final navBar = tester.widget<BottomNavigationBar>(
      find.byType(BottomNavigationBar),
    );

    expect(navBar.items.length, 2);
    expect(navBar.items[0].label, 'Detectar');
    expect(navBar.items[1].label, 'Historial');
  });

  // ── Prueba S3 ────────────────────────────────────────────────────────────────
  // Verifica el flujo de navegación completo: Detectar → Historial → Detectar,
  // comprobando que el índice activo cambia correctamente en cada transición.
  testWidgets('S3: navegación Detectar → Historial → Detectar actualiza el índice',
      (tester) async {
    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 3));

    var navBar = tester.widget<BottomNavigationBar>(
      find.byType(BottomNavigationBar),
    );
    expect(navBar.currentIndex, 0);

    await tester.tap(find.byIcon(Icons.history_outlined));
    await tester.pumpAndSettle();

    navBar = tester.widget<BottomNavigationBar>(
      find.byType(BottomNavigationBar),
    );
    expect(navBar.currentIndex, 1,
        reason: 'Al tocar Historial el índice debe ser 1');

    await tester.tap(find.byIcon(Icons.camera_alt_outlined));
    await tester.pumpAndSettle();

    navBar = tester.widget<BottomNavigationBar>(
      find.byType(BottomNavigationBar),
    );
    expect(navBar.currentIndex, 0,
        reason: 'Al tocar Detectar el índice debe volver a 0');
  });

  // ── Prueba S4 ────────────────────────────────────────────────────────────────
  // Verifica que la pantalla de Historial está accesible y muestra el título
  // correcto en el AppBar cuando se navega desde la pestaña Detectar.
  testWidgets('S4: la pantalla de Historial muestra el título correcto en AppBar',
      (tester) async {
    await tester.pumpWidget(const AppCacao());
    await tester.pump(const Duration(seconds: 3));

    await tester.tap(find.byIcon(Icons.history_outlined));
    await tester.pumpAndSettle(const Duration(seconds: 2));

    // 'Historial' aparece en el AppBar Y en la etiqueta del BottomNavigationBar
    expect(find.text('Historial'), findsAtLeastNWidgets(1));
  });
}
