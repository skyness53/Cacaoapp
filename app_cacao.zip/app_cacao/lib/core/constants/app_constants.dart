// Rutas de los modelos y etiquetas en assets
const String kModelEnfermedades = 'assets/models/ModeloEnfermedades.tflite';
const String kModelMadurez      = 'assets/models/ModeloMadurez.tflite';
const String kLabelsEnfermedades = 'assets/labels/enfermedades_labels.txt';
const String kLabelsMadurez      = 'assets/labels/madurez_labels.txt';

// Tamaño de entrada del modelo (mismo usado en entrenamiento)
const int kInputSize = 640;

// =============================================================================
// UMBRALES DE CONFIANZA — ACTIVE LEARNING
// =============================================================================
// > 83%  → resultado directo, se guarda automáticamente
// 65-83% → popup de validación al usuario, se guarda con corrección
// < 65%  → se descarta silenciosamente
// =============================================================================
const double kUmbralAutoLabel   = 0.83; // > 83% → resultado directo
const double kUmbralValidacion  = 0.65; // 65-83% → usuario valida
// < 65% → descartado

// Umbral mínimo para considerar que el modelo "vio" un objeto.
// Por debajo de este valor → imagen sin mazorca de cacao.
// Entre este y kUmbralValidacion → mazorca detectada pero no procesable.
// Se usa 5% para no rechazar imágenes válidas con baja confianza (modelo v2).
const double kUmbralDeteccion   = 0.15;

// =============================================================================
// CLASES DE CADA MODELO
// =============================================================================
// Definidas aquí una sola vez para que camera_screen, result_screen y
// cualquier otro widget futuro no las dupliquen.

const List<String> kClasesEnfermedades = [
  'Mazorca Negra', 'Sana', 'Chinche Mirid', 'Monilia',
];

const List<String> kClasesMadurez = [
  'Inmaduro', 'En proceso', 'Maduro', 'Abortado',
];

// Los colores por clase están definidos en app_theme.dart
// como Map<int, Color> kColoresEnfermedad y kColoresMadurez
