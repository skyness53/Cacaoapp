import 'package:flutter/material.dart';

// =============================================================================
// TEMA VISUAL DE LA APP — PALETA CACAO
// =============================================================================
// Todos los colores, tipografías y tamaños están aquí centralizados.
// Para cambiar la apariencia de toda la app, solo modifica este archivo.
//
// Criterios de diseño de la paleta:
//   - Cada color tiene una relación directa con el cacao, su cultivo o
//     la apariencia visual de la enfermedad/estado que representa.
//   - Fondo cálido (crema) en lugar de gris frío para conectar con lo orgánico.
//   - Primario marrón cacao para diferenciarse de apps agrícolas genéricas.
// =============================================================================

// ─── Colores principales ─────────────────────────────────────────────────────

// El color del grano de cacao tostado. Ancla visual de toda la app
// y alineado con los tonos del logo institucional.
const Color kColorPrimario    = Color(0xFF5D4037);

// Tono ámbar de la mazorca en proceso de maduración. Usado en
// elementos secundarios, acentos y el estado "en proceso".
const Color kColorSecundario  = Color(0xFFF9A825);

// Crema natural — evoca la pulpa del cacao y el marfil.
// Más agradable que el gris frío bajo la luz solar del campo.
const Color kColorFondo       = Color(0xFFFFF8F0);

const Color kColorSuperficie  = Color(0xFFFFFFFF);

// Texto oscuro con ligero tono cálido (no negro puro) para suavizar.
const Color kColorTexto       = Color(0xFF1C1207);

// Marrón cálido desaturado — mismo tono que el primario pero más suave.
// Más cohesión que un gris neutro genérico.
const Color kColorTextoSecund = Color(0xFF8D6E63);

const Color kColorError       = Color(0xFFB71C1C);
const Color kColorExito       = Color(0xFF2E7D32);

// ─── Colores por clase de enfermedad ─────────────────────────────────────────
// Cada color describe visualmente lo que ocurre en la mazorca.

const Map<int, Color> kColoresEnfermedad = {
  // La mazorca se necrosa hasta volverse una masa marrón-negra.
  // Marrón muy oscuro en lugar de rojo: describe la realidad de la enfermedad.
  0: Color(0xFF3E2723), // Mazorca Negra

  // Verde universalmente reconocido como señal de salud.
  1: Color(0xFF2E7D32), // Sana

  // El daño del insecto produce manchas rojizas y lesiones en la corteza.
  // Naranja-rojizo intenso: alerta visible, distinto a la Monilia fúngica.
  2: Color(0xFFE64A19), // Chinche Mirid

  // Morado: convención en patología vegetal para Moniliophthora roreri.
  // Contrasta claramente con todos los demás estados.
  3: Color(0xFF6A1B9A), // Monilia
};

// ─── Colores por clase de madurez ────────────────────────────────────────────
// Siguen la progresión visual real de la mazorca en campo.

const Map<int, Color> kColoresMadurez = {
  // Verde: el fruto joven no está listo, igual que en semáforos y naturaleza.
  0: Color(0xFF388E3C), // inmaduro

  // Ámbar dorado: la mazorca empieza a cambiar de verde a amarillo-naranja.
  // Mismo tono que el color secundario de la app — coherencia visual.
  1: Color(0xFFF9A825), // en_proceso

  // Naranja cacao: las mazorcas listas toman este tono rojizo-naranja intenso.
  // Color de cosecha y abundancia.
  2: Color(0xFFE65100), // maduro

  // Azul pizarra: el fruto perdido tiene tonos apagados y fríos.
  // No se confunde con ninguna enfermedad ni estado de madurez.
  3: Color(0xFF546E7A), // abortado
};

// ─── Colores semánticos de UI ─────────────────────────────────────────────────
// Usados en tarjetas informativas, estados neutros y la interfaz de cámara.
// Centralizar aquí evita buscar colores hardcodeados en los widgets.

// Tarjeta informativa (nota azul en pantalla de resultados)
const Color kColorInfoFondo  = Color(0xFFE3F2FD); // Azul muy claro
const Color kColorInfoBorde  = Color(0xFF90CAF9); // Azul claro
const Color kColorInfo       = Color(0xFF1565C0); // Azul oscuro — texto e íconos

// Tarjeta neutra (sin detección, sin datos)
const Color kColorNeutroFondo = Color(0xFFF5F5F5); // Gris muy claro
const Color kColorNeutroBorde = Color(0xFFBDBDBD); // Gris medio
const Color kColorNeutro      = Color(0xFFE0E0E0); // Gris claro — fondos sin imagen

// Tarjeta de advertencia (popup de validación 65–83%)
const Color kColorAdvertenciaFondo = Color(0xFFFFF3E0); // Naranja muy claro
const Color kColorAdvertencia      = Color(0xFFE65100); // Naranja oscuro — texto e íconos

// Overlay de cámara (fondo negro semitransparente sobre el preview)
const Color kColorOverlayCamara        = Color(0xD4000000); // ~83% opacidad
const Color kColorOverlayControles     = Color(0x78000000); // ~47% opacidad — barra inferior
const Color kColorBotonesInactivos     = Color(0x3FFFFFFF); // botón deshabilitado
const Color kColorBotonesActivos       = Color(0x8DFFFFFF); // botón habilitado
const Color kColorBordeBotonesActivos  = Color(0x8DFFFFFF); // borde botón activo
const Color kColorBordeBotonesInact    = Color(0x3DFFFFFF); // borde botón inactivo

// ─── Tipografía ──────────────────────────────────────────────────────────────

const String kFuentePrincipal = 'Roboto';

const double kTamanoTitulo    = 22.0;
const double kTamanoSubtitulo = 18.0;
const double kTamanoCuerpo    = 14.0;
const double kTamanoCaption   = 12.0;

// ─── Espaciado y bordes ──────────────────────────────────────────────────────

const double kPaddingSmall    = 8.0;
const double kPaddingMedium   = 16.0;
const double kPaddingLarge    = 24.0;
const double kRadioBorde      = 12.0;
const double kRadioBordeLarge = 20.0;

// ─── Tema global de Flutter ──────────────────────────────────────────────────

class AppTheme {
  AppTheme._();

  static ThemeData get tema => ThemeData(
    colorScheme: ColorScheme.fromSeed(
      seedColor:   kColorPrimario,
      primary:     kColorPrimario,
      secondary:   kColorSecundario,
      surface:     kColorSuperficie,
      error:       kColorError,
      brightness:  Brightness.light,
    ),
    scaffoldBackgroundColor: kColorFondo,
    fontFamily: kFuentePrincipal,
    useMaterial3: true,

    // AppBar — marrón cacao sólido, sin elevación para aspecto moderno
    appBarTheme: const AppBarTheme(
      backgroundColor: kColorPrimario,
      foregroundColor: kColorSuperficie,
      elevation:       0,
      centerTitle:     true,
      titleTextStyle: TextStyle(
        fontSize:   kTamanoSubtitulo,
        fontWeight: FontWeight.w700,
        color:      kColorSuperficie,
        letterSpacing: 0.3,
      ),
    ),

    // Botones principales — marrón cacao con texto blanco
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kColorPrimario,
        foregroundColor: kColorSuperficie,
        elevation:       0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kRadioBorde),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: kPaddingLarge,
          vertical:   kPaddingMedium,
        ),
        textStyle: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize:   kTamanoCuerpo,
          letterSpacing: 0.3,
        ),
      ),
    ),

    // Botones delineados — borde marrón cacao
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: kColorPrimario,
        side: const BorderSide(color: kColorPrimario, width: 1.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kRadioBorde),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: kPaddingLarge,
          vertical:   kPaddingMedium,
        ),
        textStyle: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize:   kTamanoCuerpo,
          letterSpacing: 0.3,
        ),
      ),
    ),

    // Cards — fondo blanco, sombra suave cálida
    cardTheme: CardThemeData(
      color:     kColorSuperficie,
      elevation: 2,
      shadowColor: kColorPrimario.withAlpha(40),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kRadioBorde),
      ),
      margin: const EdgeInsets.symmetric(
        horizontal: kPaddingMedium,
        vertical:   kPaddingSmall,
      ),
    ),

    // BottomNavigationBar — fondo blanco, seleccionado en marrón cacao
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      kColorSuperficie,
      selectedItemColor:    kColorPrimario,
      unselectedItemColor:  kColorTextoSecund,
      elevation:            8,
      selectedLabelStyle:   TextStyle(fontWeight: FontWeight.w600, fontSize: kTamanoCaption),
      unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w400, fontSize: kTamanoCaption),
    ),

    // SnackBar — marrón oscuro para coherencia
    snackBarTheme: SnackBarThemeData(
      backgroundColor: const Color(0xFF3E2723),
      contentTextStyle: const TextStyle(color: kColorSuperficie, fontSize: kTamanoCuerpo),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kRadioBorde)),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
