// =============================================================================
// CONFIGURACIÓN SUPABASE
// =============================================================================
// Reemplaza los valores con los de tu proyecto en supabase.com:
//   Project Settings → API → Project URL y anon/public key
// =============================================================================

const String kSupabaseUrl     = 'https://lewidbpyarqzlvynkieh.supabase.co';
const String kSupabaseAnonKey = 'sb_publishable_WXf9DCIUcJrLOo9VLKxYTw_Eav-SUoC';
