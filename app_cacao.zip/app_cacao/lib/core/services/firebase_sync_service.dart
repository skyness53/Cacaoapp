import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'sqlite_service.dart';

// =============================================================================
// SERVICIO DE SINCRONIZACIÓN — Supabase
// =============================================================================
// Sube al servidor las detecciones pendientes (sincronizada = false).
//
// Estructura en Supabase:
//   Tabla:   detecciones  →  metadatos de correcciones del modelo
//   Tabla:   negativos    →  metadatos de imágenes "No es cacao"
//   Bucket:  imagenes     →  imágenes originales (detecciones/ y negativos/)
//
// Cuándo se sincroniza:
//   - Automáticamente al abrir la app
// =============================================================================

class FirebaseSyncService {
  final SQLiteService    _sqlite;
  final SupabaseClient   _db = Supabase.instance.client;

  FirebaseSyncService(this._sqlite);

  // ── Sincronización principal ────────────────────────────────────────────────

  /// Sube todas las detecciones pendientes y las marca como sincronizadas.
  /// Retorna el número de registros sincronizados exitosamente.
  Future<int> sincronizar() async {
    final pendientes = await _sqlite.obtenerPendientesSincronizacion();
    print('[Sync] Pendientes: ${pendientes.length}'); // ignore: avoid_print
    if (pendientes.isEmpty) return 0;

    int exitosos = 0;

    for (final reg in pendientes) {
      try {
        if (reg.tipoModelo == 'negativo') {
          await _subirNegativo(reg);
        } else {
          await _subirDeteccion(reg);
        }
        await _sqlite.marcarSincronizada(reg.id!);
        exitosos++;
      } catch (e) {
        print('[Sync] ERROR al sincronizar registro ${reg.id}: $e'); // ignore: avoid_print
      }
    }

    if (exitosos > 0) {
      print('[Sync] $exitosos registro(s) sincronizados con Supabase.'); // ignore: avoid_print
    }
    return exitosos;
  }

  // ── Subir detección / corrección ────────────────────────────────────────────

  Future<void> _subirDeteccion(DeteccionRegistro reg) async {
    final urlImagen = await _subirImagen(
      localPath: reg.imagenPath,
      carpeta:   'detecciones',
    );

    await _db.from('detecciones').insert({
      'imagen_url'     : urlImagen,
      'tipo_modelo'    : reg.tipoModelo,
      'clase_modelo'   : reg.claseModelo,
      'confianza'      : reg.confianza,
      'clase_confirmada': reg.claseConfirmada,
      'fue_corregida'  : reg.fueCorregida,
      'timestamp'      : reg.timestamp,
    });
  }

  // ── Subir negativo ("No es cacao") ─────────────────────────────────────────

  Future<void> _subirNegativo(DeteccionRegistro reg) async {
    final urlImagen = await _subirImagen(
      localPath: reg.imagenPath,
      carpeta:   'negativos',
    );

    await _db.from('negativos').insert({
      'imagen_url': urlImagen,
      'timestamp' : reg.timestamp,
    });
  }

  // ── Subir imagen a Supabase Storage ────────────────────────────────────────

  Future<String> _subirImagen({
    required String localPath,
    required String carpeta,
  }) async {
    final archivo = File(localPath);
    if (!archivo.existsSync()) return '';

    final bytes  = await archivo.readAsBytes();
    final nombre = '$carpeta/${DateTime.now().millisecondsSinceEpoch}_${archivo.uri.pathSegments.last}';

    await _db.storage.from('Cacao').uploadBinary(nombre, bytes);
    return _db.storage.from('Cacao').getPublicUrl(nombre);
  }
}
