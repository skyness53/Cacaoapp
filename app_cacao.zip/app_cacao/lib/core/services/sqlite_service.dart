import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

// =============================================================================
// SERVICIO DE BASE DE DATOS LOCAL — SQLite
// =============================================================================
// Guarda cada detección con:
//   - Imagen (ruta local)
//   - Clase detectada por el modelo
//   - Confianza del modelo
//   - Clase confirmada por el usuario (puede diferir si hubo corrección)
//   - Si fue corregida por el usuario
//   - Timestamp
//   - Si ya fue sincronizada con Firebase
//
// Esta tabla es la base del pipeline de Active Learning:
// las imágenes con corrección del usuario se usan para reentrenar el modelo.
// =============================================================================

class DeteccionRegistro {
  final int?   id;
  final String imagenPath;      // Ruta local de la imagen
  final String tipoModelo;      // 'enfermedades' o 'madurez'
  final int    claseModelo;     // Clase que detectó el modelo
  final double confianza;       // Confianza del modelo (0.0 - 1.0)
  final int    claseConfirmada; // Clase final (puede ser corregida por usuario)
  final bool   fueCorregida;    // true = el usuario cambió la clase
  final int    timestamp;       // Unix timestamp en milisegundos
  final bool   sincronizada;    // true = ya subida a Firebase

  const DeteccionRegistro({
    this.id,
    required this.imagenPath,
    required this.tipoModelo,
    required this.claseModelo,
    required this.confianza,
    required this.claseConfirmada,
    required this.fueCorregida,
    required this.timestamp,
    this.sincronizada = false,
  });

  Map<String, dynamic> toMap() => {
    'imagen_path':      imagenPath,
    'tipo_modelo':      tipoModelo,
    'clase_modelo':     claseModelo,
    'confianza':        confianza,
    'clase_confirmada': claseConfirmada,
    'fue_corregida':    fueCorregida ? 1 : 0,
    'timestamp':        timestamp,
    'sincronizada':     sincronizada ? 1 : 0,
  };

  factory DeteccionRegistro.fromMap(Map<String, dynamic> m) =>
      DeteccionRegistro(
        id:              m['id'] as int,
        imagenPath:      m['imagen_path'] as String,
        tipoModelo:      m['tipo_modelo'] as String,
        claseModelo:     m['clase_modelo'] as int,
        confianza:       m['confianza'] as double,
        claseConfirmada: m['clase_confirmada'] as int,
        fueCorregida:    (m['fue_corregida'] as int) == 1,
        timestamp:       m['timestamp'] as int,
        sincronizada:    (m['sincronizada'] as int) == 1,
      );
}

// =============================================================================
// MODELO DE HISTORIAL (visible al usuario)
// =============================================================================
// Separado de DeteccionRegistro (Active Learning) para mantener clara la
// distinción entre datos del usuario y datos del pipeline de ML.
// El usuario controla qué entra aquí; el pipeline de AL se llena automáticamente.

class HistorialRegistro {
  final int?   id;
  final String imagenPath;
  final String etiqueta;   // Clase principal mostrada al usuario
  final double confianza;  // 0.0 si no hubo detección
  final bool   estaSana;
  final int    timestamp;

  const HistorialRegistro({
    this.id,
    required this.imagenPath,
    required this.etiqueta,
    required this.confianza,
    required this.estaSana,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
    'imagen_path': imagenPath,
    'etiqueta':    etiqueta,
    'confianza':   confianza,
    'esta_sana':   estaSana ? 1 : 0,
    'timestamp':   timestamp,
  };

  factory HistorialRegistro.fromMap(Map<String, dynamic> m) =>
      HistorialRegistro(
        id:          m['id']          as int,
        imagenPath:  m['imagen_path'] as String,
        etiqueta:    m['etiqueta']    as String,
        confianza:   m['confianza']   as double,
        estaSana:    (m['esta_sana']  as int) == 1,
        timestamp:   m['timestamp']   as int,
      );
}

// =============================================================================

class SQLiteService {
  static const _dbName    = 'app_cacao.db';
  static const _dbVersion = 2;   // v2: tabla historial
  static const _tabla     = 'detecciones';
  static const _tablaHist = 'historial';
  static const _limiteHist = 20; // Máximo de entradas visibles al usuario

  Database? _db;

  // ── Inicialización ──────────────────────────────────────────────────────────

  Future<void> inicializar() async {
    final dbPath = await getDatabasesPath();
    _db = await openDatabase(
      join(dbPath, _dbName),
      version: _dbVersion,
      onCreate: _crearTablas,
      onUpgrade: _migrar,
    );
  }

  Future<void> _crearTablas(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $_tabla (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        imagen_path     TEXT    NOT NULL,
        tipo_modelo     TEXT    NOT NULL,
        clase_modelo    INTEGER NOT NULL,
        confianza       REAL    NOT NULL,
        clase_confirmada INTEGER NOT NULL,
        fue_corregida   INTEGER NOT NULL DEFAULT 0,
        timestamp       INTEGER NOT NULL,
        sincronizada    INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await _crearTablaHistorial(db);
  }

  Future<void> _migrar(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) await _crearTablaHistorial(db);
  }

  Future<void> _crearTablaHistorial(Database db) async {
    await db.execute('''
      CREATE TABLE $_tablaHist (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        imagen_path TEXT    NOT NULL,
        etiqueta    TEXT    NOT NULL,
        confianza   REAL    NOT NULL,
        esta_sana   INTEGER NOT NULL DEFAULT 0,
        timestamp   INTEGER NOT NULL
      )
    ''');
  }

  // ── Operaciones CRUD ────────────────────────────────────────────────────────

  /// Guarda una detección en la base de datos local (pipeline Active Learning).
  /// Retorna el id del registro insertado.
  Future<int> guardarDeteccion(DeteccionRegistro registro) async {
    return await _db!.insert(_tabla, registro.toMap());
  }

  // ── Historial (visible al usuario) ──────────────────────────────────────────

  /// Guarda una entrada en el historial del usuario.
  /// Mantiene un máximo de [_limiteHist] entradas, eliminando las más antiguas.
  Future<void> guardarEnHistorial(HistorialRegistro registro) async {
    await _db!.insert(_tablaHist, registro.toMap());
    await _db!.execute('''
      DELETE FROM $_tablaHist
      WHERE id NOT IN (
        SELECT id FROM $_tablaHist ORDER BY timestamp DESC LIMIT $_limiteHist
      )
    ''');
  }

  /// Retorna las últimas [_limiteHist] entradas del historial, más recientes primero.
  Future<List<HistorialRegistro>> obtenerHistorial() async {
    final maps = await _db!.query(
      _tablaHist,
      orderBy: 'timestamp DESC',
      limit:   _limiteHist,
    );
    return maps.map(HistorialRegistro.fromMap).toList();
  }

  /// Elimina una entrada del historial por id.
  Future<void> eliminarDeHistorial(int id) async {
    await _db!.delete(_tablaHist, where: 'id = ?', whereArgs: [id]);
  }

  // ── Negativos (imágenes que no son cacao) ───────────────────────────────────

  /// Copia la imagen a la carpeta de negativos y registra en la tabla de
  /// detecciones con tipoModelo='negativo'. Estas imágenes se usarán como
  /// fondo (background) en futuros reentrenamientos.
  Future<void> guardarNegativo(String imagenPath) async {
    final dir = await getApplicationDocumentsDirectory();
    final carpeta = Directory(join(dir.path, 'negativos'));
    if (!carpeta.existsSync()) carpeta.createSync(recursive: true);

    final nombre  = 'neg_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final destino = join(carpeta.path, nombre);
    await File(imagenPath).copy(destino);

    await _db!.insert(_tabla, DeteccionRegistro(
      imagenPath:      destino,
      tipoModelo:      'negativo',
      claseModelo:     -1,
      confianza:       0.0,
      claseConfirmada: -1,
      fueCorregida:    true,
      timestamp:       DateTime.now().millisecondsSinceEpoch,
    ).toMap());
  }

  /// Retorna todas las detecciones ordenadas por timestamp descendente.
  Future<List<DeteccionRegistro>> obtenerTodas() async {
    final maps = await _db!.query(
      _tabla,
      orderBy: 'timestamp DESC',
    );
    return maps.map(DeteccionRegistro.fromMap).toList();
  }

  /// Retorna las detecciones que aún no han sido sincronizadas con Firebase.
  Future<List<DeteccionRegistro>> obtenerPendientesSincronizacion() async {
    final maps = await _db!.query(
      _tabla,
      where:     'sincronizada = ?',
      whereArgs: [0],
    );
    return maps.map(DeteccionRegistro.fromMap).toList();
  }

  /// Marca una detección como sincronizada con Firebase.
  Future<void> marcarSincronizada(int id) async {
    await _db!.update(
      _tabla,
      {'sincronizada': 1},
      where:     'id = ?',
      whereArgs: [id],
    );
  }

  void dispose() => _db?.close();
}
