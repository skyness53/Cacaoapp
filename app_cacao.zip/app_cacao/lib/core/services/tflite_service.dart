import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:flutter/foundation.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import '../constants/app_constants.dart';

// =============================================================================
// SERVICIO DE INFERENCIA TFLITE
// =============================================================================
// Maneja la carga y ejecución de los dos modelos YOLO11s:
//   - Modelo de enfermedades (5 clases)
//   - Modelo de madurez (4 clases)
//
// Flujo de uso:
//   1. inicializar() — carga ambos modelos al arrancar la app
//   2. detectarEnfermedades(imagen) → DeteccionResultado?
//   3. Si resultado es "Sana" → detectarMadurez(imagen) → DeteccionResultado?
// =============================================================================

/// Resultado completo de la inferencia:
///   - [deteccion] null si la confianza no alcanzó [kUmbralValidacion]
///   - [hayMazorca] true si el modelo detectó algo por encima de [kUmbralDeteccion],
///     aunque no alcanzara el umbral de validación
class ResultadoInferencia {
  final DeteccionResultado? deteccion;
  final bool hayMazorca;

  const ResultadoInferencia({
    required this.deteccion,
    required this.hayMazorca,
  });
}

/// Resultado de la mejor detección encontrada en una imagen
class DeteccionResultado {
  final int    claseId;
  final String claseNombre;
  final double confianza;    // Valor entre 0.0 y 1.0
  final List<double> bbox;   // [x1, y1, x2, y2] normalizados 0-1

  const DeteccionResultado({
    required this.claseId,
    required this.claseNombre,
    required this.confianza,
    required this.bbox,
  });
}

class TFLiteService {
  Interpreter? _interpreterEnfermedades;
  Interpreter? _interpreterMadurez;

  List<String> _labelsEnfermedades = [];
  List<String> _labelsMadurez      = [];

  bool get listo =>
      _interpreterEnfermedades != null && _interpreterMadurez != null;

  // ── Inicialización ──────────────────────────────────────────────────────────

  /// Carga ambos modelos y sus etiquetas desde assets
  Future<void> inicializar() async {
    _interpreterEnfermedades = await Interpreter.fromAsset(kModelEnfermedades);
    _interpreterMadurez      = await Interpreter.fromAsset(kModelMadurez);

    _labelsEnfermedades = await _cargarEtiquetas(kLabelsEnfermedades);
    _labelsMadurez      = await _cargarEtiquetas(kLabelsMadurez);

    debugPrint('[TFLiteService] Modelos cargados correctamente');
  }

  Future<List<String>> _cargarEtiquetas(String asset) async {
    final contenido = await rootBundle.loadString(asset);
    return contenido
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();
  }

  // ── API pública ─────────────────────────────────────────────────────────────

  /// Corre el modelo de enfermedades.
  Future<ResultadoInferencia> detectarEnfermedades(File imagen) async {
    return _inferir(imagen, _interpreterEnfermedades!, _labelsEnfermedades);
  }

  /// Corre el modelo de madurez.
  Future<ResultadoInferencia> detectarMadurez(File imagen) async {
    return _inferir(imagen, _interpreterMadurez!, _labelsMadurez);
  }

  // ── Preprocesamiento ────────────────────────────────────────────────────────

  /// Redimensiona la imagen a 640×640 y la convierte a Int8List.
  /// El modelo full-integer INT8 espera valores en rango [-128, 127].
  Int8List _preprocesar(File imagenFile) {
    final bytes   = imagenFile.readAsBytesSync();
    final imagen  = img.decodeImage(bytes)!;
    final resized = img.copyResize(imagen, width: kInputSize, height: kInputSize);

    final input = Int8List(kInputSize * kInputSize * 3);
    int idx = 0;
    for (int y = 0; y < kInputSize; y++) {
      for (int x = 0; x < kInputSize; x++) {
        final pixel = resized.getPixel(x, y);
        // Mapea 0-255 → -128 a 127 restando 128
        input[idx++] = pixel.r.toInt() - 128;
        input[idx++] = pixel.g.toInt() - 128;
        input[idx++] = pixel.b.toInt() - 128;
      }
    }
    return input;
  }

  // ── Inferencia ──────────────────────────────────────────────────────────────

  Future<ResultadoInferencia> _inferir(
    File          imagen,
    Interpreter   interprete,
    List<String>  etiquetas,
  ) async {
    final inputData = _preprocesar(imagen);

    // Lee los parámetros de cuantización del tensor de salida.
    // Necesarios para convertir los valores int8 crudos a float reales.
    final outTensor  = interprete.getOutputTensor(0);
    final qScale     = outTensor.params.scale;
    final qZeroPoint = outTensor.params.zeroPoint;
    final outShape   = outTensor.shape; // [1, num_campos, num_detecciones]

    // Buffer de salida: lista plana de doubles (TFLite la llena con int8 → double)
    final totalElems = outShape.reduce((a, b) => a * b);
    final outputFlat = List.filled(totalElems, 0.0);
    final outputData = outputFlat.reshape(outShape);

    interprete.run(
      inputData.reshape([1, kInputSize, kInputSize, 3]),
      outputData,
    );

    return _parsearSalida(outputData, etiquetas, qScale, qZeroPoint);
  }

  // ── Parseo de salida YOLO ───────────────────────────────────────────────────

  /// Parsea la salida YOLO con formato [1, num_campos, num_detecciones].
  /// num_campos = 4 (bbox) + num_clases
  ///
  /// Aplica dequantización y devuelve solo la MEJOR detección por encima
  /// del umbral mínimo, o null si ninguna supera el umbral.
  ResultadoInferencia _parsearSalida(
    dynamic       output,
    List<String>  etiquetas,
    double        qScale,
    int           qZeroPoint,
  ) {
    final data           = output[0] as List;
    final numDetecciones = (data[0] as List).length;
    final numClases      = etiquetas.length;

    double deq(dynamic raw) =>
        ((raw as num).toInt() - qZeroPoint) * qScale;

    double mejorConf  = 0;
    int    mejorClase = -1;
    int    mejorIdx   = -1;

    for (int d = 0; d < numDetecciones; d++) {
      for (int c = 0; c < numClases; c++) {
        final conf = deq((data[4 + c] as List)[d]);
        if (conf > mejorConf) {
          mejorConf  = conf;
          mejorClase = c;
          mejorIdx   = d;
        }
      }
    }

    // El modelo detectó algo si supera el umbral mínimo de detección,
    // aunque no alcance el umbral de validación.
    final hayMazorca = mejorConf >= kUmbralDeteccion;

    // No alcanzó el umbral de validación → sin detección procesable
    if (mejorClase == -1 || mejorConf < kUmbralValidacion) {
      return ResultadoInferencia(deteccion: null, hayMazorca: hayMazorca);
    }

    final xc = deq((data[0] as List)[mejorIdx]);
    final yc = deq((data[1] as List)[mejorIdx]);
    final w  = deq((data[2] as List)[mejorIdx]);
    final h  = deq((data[3] as List)[mejorIdx]);

    return ResultadoInferencia(
      hayMazorca: true,
      deteccion: DeteccionResultado(
        claseId:     mejorClase,
        claseNombre: etiquetas[mejorClase],
        confianza:   mejorConf.clamp(0.0, 1.0),
        bbox: [
          ((xc - w / 2) / kInputSize).clamp(0.0, 1.0),
          ((yc - h / 2) / kInputSize).clamp(0.0, 1.0),
          ((xc + w / 2) / kInputSize).clamp(0.0, 1.0),
          ((yc + h / 2) / kInputSize).clamp(0.0, 1.0),
        ],
      ),
    );
  }

  // ── Limpieza ────────────────────────────────────────────────────────────────

  void dispose() {
    _interpreterEnfermedades?.close();
    _interpreterMadurez?.close();
  }
}
