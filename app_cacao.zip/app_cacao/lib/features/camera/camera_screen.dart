import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/constants/app_constants.dart';
import '../../core/constants/app_theme.dart';
import '../../core/services/firebase_sync_service.dart';
import '../../core/services/sqlite_service.dart';
import '../../core/services/tflite_service.dart';
import '../../shared/widgets/validacion_dialog.dart';
import '../result/result_screen.dart';

// =============================================================================
// PANTALLA DE CÁMARA
// =============================================================================
// Flujo de análisis:
//
//   1. Muestra preview en vivo con marco de encuadre
//   2. El usuario captura (botón) o elige de galería
//   3. Corre modelo de enfermedades
//      ├── null (< 65%)      → descarta, muestra mensaje
//      ├── 65–83%            → popup validación usuario
//      └── > 83%             → resultado directo
//   4. Si detección es "Sana" → corre modelo de madurez (mismo flujo)
//   5. Si tiene enfermedad    → muestra solo la enfermedad
//   6. Guarda en SQLite para Active Learning
// =============================================================================

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with WidgetsBindingObserver {
  // ── Cámara ──────────────────────────────────────────────────────────────────
  CameraController? _camController;
  bool _camaraLista       = false;
  bool _permisoDenegado   = false;
  bool _iniciandoCamara   = false;

  // ── Modelos ─────────────────────────────────────────────────────────────────
  final TFLiteService        _tflite = TFLiteService();
  final SQLiteService        _sqlite = SQLiteService();
  late final FirebaseSyncService _sync;
  bool _modeloListo = false;
  bool _procesando  = false;

  // Las etiquetas de clases viven en app_constants.dart:
  // kClasesEnfermedades y kClasesMadurez

  // ── Ciclo de vida ────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _inicializar();
  }

  Future<void> _inicializar() async {
    await Future.wait([_inicializarModelo(), _inicializarCamara()]);
  }

  Future<void> _inicializarModelo() async {
    await Future.wait([_tflite.inicializar(), _sqlite.inicializar()]);
    _sync = FirebaseSyncService(_sqlite);
    _sync.sincronizar(); // en segundo plano, sin await
    if (mounted) setState(() => _modeloListo = true);
  }

  Future<void> _inicializarCamara() async {
    if (_iniciandoCamara) return;
    _iniciandoCamara = true;
    try {
      // Verificar estado antes de pedir: evita la excepción
      // "a request for permissions is already running" si se llama
      // desde initState y didChangeAppLifecycleState al mismo tiempo.
      var status = await Permission.camera.status;
      if (status.isDenied) status = await Permission.camera.request();
      if (status.isDenied || status.isPermanentlyDenied) {
        if (mounted) setState(() => _permisoDenegado = true);
        return;
      }
      final cameras = await availableCameras();
      if (cameras.isEmpty) return;
      _camController = CameraController(
        cameras.first,
        ResolutionPreset.high,
        enableAudio: false,
      );
      await _camController!.initialize();
      if (mounted) setState(() => _camaraLista = true);
    } finally {
      _iniciandoCamara = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_camController == null || !_camController!.value.isInitialized) return;
    if (state == AppLifecycleState.inactive) {
      _camController?.dispose();
      _camaraLista = false;
    } else if (state == AppLifecycleState.resumed) {
      _inicializarCamara();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _camController?.dispose();
    _tflite.dispose();
    _sqlite.dispose();
    super.dispose();
  }

  // ── Captura ──────────────────────────────────────────────────────────────────

  Future<void> _tomarFoto() async {
    if (!_camaraLista || _procesando || !_modeloListo) return;
    final xfile = await _camController!.takePicture();
    await _analizarImagen(File(xfile.path));
  }

  Future<void> _seleccionarDeGaleria() async {
    final imagen = await ImagePicker().pickImage(
      source:       ImageSource.gallery,
      imageQuality: 90,
    );
    if (imagen != null) await _analizarImagen(File(imagen.path));
  }

  // ── Flujo principal de análisis ──────────────────────────────────────────────

  Future<void> _analizarImagen(File imagen) async {
    if (!_modeloListo || _procesando) return;
    setState(() => _procesando = true);

    // Espera a que Flutter termine de pintar el frame con el overlay
    // antes de que las operaciones síncronas bloqueen el hilo principal.
    await WidgetsBinding.instance.endOfFrame;

    try {
      final infEnfermedad = await _tflite.detectarEnfermedades(imagen);

      final resultadoEnfermedad = await _procesarDeteccion(
        deteccion:  infEnfermedad.deteccion,
        labels:     kClasesEnfermedades,
        colores:    kColoresEnfermedad,
        tipoModelo: 'enfermedades',
        imagen:     imagen,
      );

      if (resultadoEnfermedad == _ResultadoProcesado.descartado) return;

      final claseEnfermedad = resultadoEnfermedad.claseId;
      final estaSana        = claseEnfermedad == 1;

      DeteccionResultado? detMadurezFinal;
      int?               claseMadurezFinal;

      if (estaSana) {
        final infMadurez = await _tflite.detectarMadurez(imagen);

        final resultadoMadurez = await _procesarDeteccion(
          deteccion:  infMadurez.deteccion,
          labels:     kClasesMadurez,
          colores:    kColoresMadurez,
          tipoModelo: 'madurez',
          imagen:     imagen,
        );

        if (resultadoMadurez != _ResultadoProcesado.descartado) {
          detMadurezFinal   = infMadurez.deteccion;
          claseMadurezFinal = resultadoMadurez.claseId;
        }
      }

      final detEnfermedadFinal = (claseEnfermedad != null && infEnfermedad.deteccion != null)
          ? DeteccionResultado(
              claseId:     claseEnfermedad,
              claseNombre: kClasesEnfermedades[claseEnfermedad],
              confianza:   infEnfermedad.deteccion!.confianza,
              bbox:        infEnfermedad.deteccion!.bbox,
            )
          : null;

      final detMadurezAjustada = (claseMadurezFinal != null && detMadurezFinal != null)
          ? DeteccionResultado(
              claseId:     claseMadurezFinal,
              claseNombre: kClasesMadurez[claseMadurezFinal],
              confianza:   detMadurezFinal.confianza,
              bbox:        detMadurezFinal.bbox,
            )
          : null;

      if (!mounted) return;

      // Sin mazorca: solo mensaje emergente, no navegar a resultados
      if (!infEnfermedad.hayMazorca) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:         Text('No se identificó ninguna mazorca de cacao en la imagen'),
            backgroundColor: kColorError,
            behavior:        SnackBarBehavior.floating,
          ),
        );
        return;
      }

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            imagen:        imagen,
            detEnfermedad: detEnfermedadFinal,
            detMadurez:    detMadurezAjustada,
            estaSana:      estaSana,
            sqlite:        _sqlite,
          ),
        ),
      );

    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al analizar imagen: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _procesando = false);
    }
  }

  // ── Lógica de umbrales + popup ───────────────────────────────────────────────

  Future<_ResultadoProcesado> _procesarDeteccion({
    required DeteccionResultado? deteccion,
    required List<String>        labels,
    required Map<int, Color>     colores,
    required String              tipoModelo,
    required File                imagen,
  }) async {
    if (deteccion == null || deteccion.confianza < kUmbralValidacion) {
      return _ResultadoProcesado.nulo();
    }

    if (deteccion.confianza >= kUmbralAutoLabel) {
      await _sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath:      imagen.path,
        tipoModelo:      tipoModelo,
        claseModelo:     deteccion.claseId,
        confianza:       deteccion.confianza,
        claseConfirmada: deteccion.claseId,
        fueCorregida:    false,
        timestamp:       DateTime.now().millisecondsSinceEpoch,
      ));
      return _ResultadoProcesado(claseId: deteccion.claseId);
    }

    if (!mounted) return _ResultadoProcesado.descartado;

    final validacion = await showDialog<ValidacionResultado>(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValidacionDialog(
        deteccion:  deteccion,
        opciones:   labels,
        colores:    colores,
        tipoModelo: tipoModelo,
      ),
    );

    if (validacion == null) return _ResultadoProcesado.descartado;

    // "No es cacao" → guardar como negativo y descartar
    if (validacion.claseConfirmada == -1) {
      await _sqlite.guardarNegativo(imagen.path);
      _sync.sincronizar();
      return _ResultadoProcesado.descartado;
    }

    await _sqlite.guardarDeteccion(DeteccionRegistro(
      imagenPath:      imagen.path,
      tipoModelo:      tipoModelo,
      claseModelo:     deteccion.claseId,
      confianza:       deteccion.confianza,
      claseConfirmada: validacion.claseConfirmada,
      fueCorregida:    validacion.fueCorregido,
      timestamp:       DateTime.now().millisecondsSinceEpoch,
    ));
    return _ResultadoProcesado(claseId: validacion.claseConfirmada);
  }

  // ── UI ───────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Preview de cámara o placeholder ─────────────────────────────
          _camaraLista
              ? CameraPreview(_camController!)
              : _buildPlaceholder(),

          // ── Marco de encuadre ────────────────────────────────────────────
          if (_camaraLista && !_procesando)
            CustomPaint(painter: _MarcoPainter()),

          // ── Texto de guía ────────────────────────────────────────────────
          if (_camaraLista && !_procesando)
            Positioned(
              top:   MediaQuery.of(context).padding.top + kPaddingLarge,
              left:  0,
              right: 0,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kPaddingMedium,
                    vertical:   kPaddingSmall / 2,
                  ),
                  decoration: BoxDecoration(
                    color:        Colors.black.withAlpha(120),
                    borderRadius: BorderRadius.circular(kRadioBorde),
                  ),
                  child: const Text(
                    'Centra la mazorca en el marco',
                    style: TextStyle(color: Colors.white, fontSize: kTamanoCuerpo),
                  ),
                ),
              ),
            ),

          // ── Overlay de carga ─────────────────────────────────────────────
          if (_procesando) _buildOverlayCarga(),

          // ── Controles inferiores ─────────────────────────────────────────
          if (!_procesando)
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: _buildControles(),
            ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_permisoDenegado) ...[
              const Icon(Icons.no_photography_outlined,
                  size: 64, color: kColorBotonesActivos),
              const SizedBox(height: kPaddingMedium),
              const Text(
                'Permiso de cámara denegado',
                style: TextStyle(color: kColorBotonesActivos, fontSize: kTamanoCuerpo),
              ),
              const SizedBox(height: kPaddingSmall),
              TextButton(
                onPressed: openAppSettings,
                child: const Text('Abrir configuración',
                    style: TextStyle(color: kColorPrimario)),
              ),
            ] else ...[
              const CircularProgressIndicator(color: kColorBotonesActivos),
              const SizedBox(height: kPaddingMedium),
              const Text(
                'Iniciando cámara...',
                style: TextStyle(color: kColorBotonesActivos, fontSize: kTamanoCuerpo),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildOverlayCarga() {
    return Container(
      color: Colors.black.withAlpha(180),
      child: const Center(
        child: CircularProgressIndicator(color: Colors.white),
      ),
    );
  }

  Widget _buildControles() {
    final listo = _camaraLista && _modeloListo;

    return Container(
      padding: EdgeInsets.fromLTRB(
        kPaddingLarge,
        kPaddingLarge,
        kPaddingLarge,
        MediaQuery.of(context).padding.bottom + kPaddingLarge,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end:   Alignment.topCenter,
          colors: [
            Colors.black.withAlpha(200),
            Colors.transparent,
          ],
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Botón galería (izquierda)
          _botonCircular(
            icon:      Icons.photo_library_outlined,
            onPressed: listo ? _seleccionarDeGaleria : null,
            size:      48,
          ),

          // Botón captura (centro)
          GestureDetector(
            onTap: listo ? _tomarFoto : null,
            child: Container(
              width:  72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                color: listo
                    ? Colors.white.withAlpha(220)
                    : Colors.white.withAlpha(80),
              ),
              child: Center(
                child: Container(
                  width:  56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: listo ? kColorPrimario : kColorTextoSecund,
                  ),
                  child: !_modeloListo
                      ? const Padding(
                          padding: EdgeInsets.all(14),
                          child:   CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.camera_alt, color: Colors.white, size: 28),
                ),
              ),
            ),
          ),

          // Espacio simétrico (derecha) — reservado para futuras acciones
          const SizedBox(width: 48, height: 48),
        ],
      ),
    );
  }

  Widget _botonCircular({
    required IconData icon,
    required VoidCallback? onPressed,
    double size = 48,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width:  size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.black.withAlpha(120),
          border: Border.all(
            color: onPressed != null ? kColorBordeBotonesActivos : kColorBordeBotonesInact,
          ),
        ),
        child: Icon(
          icon,
          color: onPressed != null ? Colors.white : Colors.white38,
          size:  size * 0.5,
        ),
      ),
    );
  }
}

// ── Marco de encuadre ──────────────────────────────────────────────────────────

/// Dibuja un overlay oscuro con un recuadre central transparente y esquinas
/// decorativas en verde, para guiar al usuario a encuadrar la mazorca.
class _MarcoPainter extends CustomPainter {
  static const double _fraccion    = 0.72; // fracción del ancho menor
  static const double _radioEsq    = 12.0; // radio de las esquinas redondeadas
  static const double _longEsq     = 28.0; // largo de las líneas de esquina
  static const double _grosorEsq   = 3.5;

  @override
  void paint(Canvas canvas, Size size) {
    final lado   = size.shortestSide * _fraccion;
    final left   = (size.width  - lado) / 2;
    final top    = (size.height - lado) / 2;
    final rect   = Rect.fromLTWH(left, top, lado, lado);
    final rrect  = RRect.fromRectAndRadius(rect, const Radius.circular(_radioEsq));

    // Overlay oscuro con recorte central
    final overlayPath = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRRect(rrect);

    canvas.drawPath(
      overlayPath,
      Paint()..color = Colors.black.withAlpha(130),
    );

    // Esquinas decorativas
    final paintEsq = Paint()
      ..color       = kColorPrimario
      ..strokeWidth = _grosorEsq
      ..strokeCap   = StrokeCap.round
      ..style       = PaintingStyle.stroke;

    // Superior izquierda
    canvas.drawLine(Offset(left, top + _longEsq), Offset(left, top + _radioEsq), paintEsq);
    canvas.drawArc(Rect.fromLTWH(left, top, _radioEsq * 2, _radioEsq * 2),
        3.14159, 3.14159 / 2, false, paintEsq);
    canvas.drawLine(Offset(left + _radioEsq, top), Offset(left + _longEsq, top), paintEsq);

    // Superior derecha
    final r = left + lado;
    canvas.drawLine(Offset(r - _longEsq, top), Offset(r - _radioEsq, top), paintEsq);
    canvas.drawArc(Rect.fromLTWH(r - _radioEsq * 2, top, _radioEsq * 2, _radioEsq * 2),
        -3.14159 / 2, 3.14159 / 2, false, paintEsq);
    canvas.drawLine(Offset(r, top + _radioEsq), Offset(r, top + _longEsq), paintEsq);

    // Inferior izquierda
    final b = top + lado;
    canvas.drawLine(Offset(left, b - _longEsq), Offset(left, b - _radioEsq), paintEsq);
    canvas.drawArc(Rect.fromLTWH(left, b - _radioEsq * 2, _radioEsq * 2, _radioEsq * 2),
        3.14159 / 2, 3.14159 / 2, false, paintEsq);
    canvas.drawLine(Offset(left + _radioEsq, b), Offset(left + _longEsq, b), paintEsq);

    // Inferior derecha
    canvas.drawLine(Offset(r - _longEsq, b), Offset(r - _radioEsq, b), paintEsq);
    canvas.drawArc(Rect.fromLTWH(r - _radioEsq * 2, b - _radioEsq * 2, _radioEsq * 2, _radioEsq * 2),
        0, 3.14159 / 2, false, paintEsq);
    canvas.drawLine(Offset(r, b - _radioEsq), Offset(r, b - _longEsq), paintEsq);
  }

  @override
  bool shouldRepaint(_MarcoPainter old) => false;
}

// ── Clase auxiliar interna ─────────────────────────────────────────────────────

class _ResultadoProcesado {
  final int?  claseId;
  final bool  _esDescartado;

  const _ResultadoProcesado({required this.claseId}) : _esDescartado = false;
  const _ResultadoProcesado.nulo() : claseId = null, _esDescartado = false;

  static const _ResultadoProcesado descartado =
      _ResultadoProcesado._interno(esDescartado: true);

  const _ResultadoProcesado._interno({required bool esDescartado})
      : claseId = null, _esDescartado = esDescartado;

  @override
  bool operator ==(Object other) =>
      other is _ResultadoProcesado && other._esDescartado == _esDescartado;

  @override
  int get hashCode => _esDescartado.hashCode;
}
