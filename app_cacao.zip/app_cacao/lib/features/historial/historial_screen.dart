import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_constants.dart';
import '../../core/constants/app_theme.dart';
import '../../core/services/sqlite_service.dart';

// =============================================================================
// PANTALLA DE HISTORIAL
// =============================================================================
// Muestra las últimas 20 detecciones guardadas manualmente por el usuario.
// El usuario decide qué guardar desde la pantalla de resultados.
// Al llegar a 20 entradas, la más antigua se elimina automáticamente.
// =============================================================================

class HistorialScreen extends StatefulWidget {
  const HistorialScreen({super.key});

  @override
  State<HistorialScreen> createState() => _HistorialScreenState();
}

class _HistorialScreenState extends State<HistorialScreen> {
  final SQLiteService _sqlite = SQLiteService();
  List<HistorialRegistro> _registros = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    await _sqlite.inicializar();
    final registros = await _sqlite.obtenerHistorial();
    if (mounted) setState(() { _registros = registros; _cargando = false; });
  }

  Future<void> _eliminar(HistorialRegistro reg) async {
    await _sqlite.eliminarDeHistorial(reg.id!);
    setState(() => _registros.remove(reg));
  }

  @override
  void dispose() {
    // No cerramos la DB aquí porque CameraScreen comparte la misma conexión.
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historial'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: kPaddingSmall),
            child: Center(
              child: Text(
                '${_registros.length}/20',
                style: const TextStyle(color: kColorSuperficie, fontSize: kTamanoCuerpo),
              ),
            ),
          ),
        ],
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _registros.isEmpty
              ? _pantallaSinDatos()
              : RefreshIndicator(
                  onRefresh: _cargar,
                  child: ListView.builder(
                    padding:      const EdgeInsets.symmetric(vertical: kPaddingSmall),
                    itemCount:    _registros.length,
                    itemBuilder:  (_, i) => _tarjeta(_registros[i]),
                  ),
                ),
    );
  }

  // ── Widgets ─────────────────────────────────────────────────────────────────

  Widget _pantallaSinDatos() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(Icons.history_outlined, size: 80, color: kColorTextoSecund),
          SizedBox(height: kPaddingLarge),
          Text(
            'Sin detecciones guardadas',
            style: TextStyle(
              fontSize:   kTamanoSubtitulo,
              fontWeight: FontWeight.w600,
              color:      kColorTexto,
            ),
          ),
          SizedBox(height: kPaddingSmall),
          Text(
            'Analiza una mazorca y guarda el resultado',
            style: TextStyle(fontSize: kTamanoCuerpo, color: kColorTextoSecund),
          ),
        ],
      ),
    );
  }

  Color _colorParaEtiqueta(String etiqueta, bool estaSana) {
    final idxEnf = kClasesEnfermedades.indexOf(etiqueta);
    if (idxEnf != -1) return kColoresEnfermedad[idxEnf] ?? kColorPrimario;
    final idxMad = kClasesMadurez.indexOf(etiqueta);
    if (idxMad != -1) return kColoresMadurez[idxMad] ?? kColorPrimario;
    return estaSana ? kColorExito : kColorError;
  }

  Widget _tarjeta(HistorialRegistro reg) {
    final colorTarjeta = _colorParaEtiqueta(reg.etiqueta, reg.estaSana);
    final porcentaje   = reg.confianza > 0
        ? '${(reg.confianza * 100).toStringAsFixed(1)}%'
        : '—';
    final fecha = DateFormat('dd/MM/yyyy  HH:mm')
        .format(DateTime.fromMillisecondsSinceEpoch(reg.timestamp));

    final imagenExiste = File(reg.imagenPath).existsSync();

    return Dismissible(
      key:        ValueKey(reg.id),
      direction:  DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding:   const EdgeInsets.only(right: kPaddingLarge),
        color:     kColorError,
        child:     const Icon(Icons.delete_outline, color: Colors.white),
      ),
      onDismissed: (_) => _eliminar(reg),
      child: Card(
        margin: const EdgeInsets.symmetric(
          horizontal: kPaddingMedium, vertical: kPaddingSmall / 2,
        ),
        child: Row(
          children: [
            // Miniatura de la imagen
            ClipRRect(
              borderRadius: const BorderRadius.horizontal(
                left: Radius.circular(kRadioBorde),
              ),
              child: imagenExiste
                  ? Image.file(
                      File(reg.imagenPath),
                      width: 80, height: 80,
                      fit:   BoxFit.cover,
                    )
                  : Container(
                      width: 80, height: 80,
                      color: kColorNeutro,
                      child: const Icon(Icons.image_not_supported_outlined,
                          color: kColorTextoSecund),
                    ),
            ),

            // Información
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: kPaddingMedium, vertical: kPaddingSmall,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Etiqueta con indicador de color
                    Row(
                      children: [
                        Container(
                          width: 10, height: 10,
                          decoration: BoxDecoration(
                            color: colorTarjeta, shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            reg.etiqueta,
                            style: TextStyle(
                              fontSize:   kTamanoCuerpo,
                              fontWeight: FontWeight.bold,
                              color:      colorTarjeta,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Text(
                          porcentaje,
                          style: const TextStyle(
                            fontSize: kTamanoCaption,
                            color:    kColorTextoSecund,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      fecha,
                      style: const TextStyle(
                        fontSize: kTamanoCaption,
                        color:    kColorTextoSecund,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}
