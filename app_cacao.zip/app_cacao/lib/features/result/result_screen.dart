import 'dart:io';
import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/constants/app_theme.dart';
import '../../core/services/firebase_sync_service.dart';
import '../../core/services/sqlite_service.dart';
import '../../core/services/tflite_service.dart';

// =============================================================================
// PANTALLA DE RESULTADOS
// =============================================================================
// Muestra el resultado del análisis de una mazorca:
//
//   - Si tiene enfermedad → muestra solo la enfermedad detectada
//   - Si está sana        → muestra solo el estado de madurez
//   - Si no se detectó nada → muestra mensaje informativo
// =============================================================================

class ResultScreen extends StatefulWidget {
  final File                 imagen;
  final DeteccionResultado?  detEnfermedad;
  final DeteccionResultado?  detMadurez;
  final bool                 estaSana;
  final SQLiteService        sqlite;

  const ResultScreen({
    super.key,
    required this.imagen,
    required this.detEnfermedad,
    required this.detMadurez,
    required this.estaSana,
    required this.sqlite,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  bool _guardado   = false;
  bool _guardando  = false;
  bool _corregido  = false;

  // ── Corrección de resultado (Active Learning manual) ────────────────────────

  Future<void> _corregir() async {
    // Determina qué modelo se está mostrando al usuario
    final esEnfermedad = !widget.estaSana && widget.detEnfermedad != null;
    final clases     = esEnfermedad ? kClasesEnfermedades : kClasesMadurez;
    final colores    = esEnfermedad ? kColoresEnfermedad  : kColoresMadurez;
    final det        = esEnfermedad ? widget.detEnfermedad! : widget.detMadurez!;
    final tipoModelo = esEnfermedad ? 'enfermedades' : 'madurez';

    // -1 = sentinel "No es cacao"
    int seleccionado = det.claseId;

    final claseCorregida = await showDialog<int>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx2, setS) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(kRadioBordeLarge),
          ),
          title: const Row(
            children: [
              Icon(Icons.edit_outlined, color: kColorSecundario),
              SizedBox(width: kPaddingSmall),
              Text('Corregir resultado',
                  style: TextStyle(fontSize: kTamanoSubtitulo)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '¿Cuál es la clase correcta?',
                style: TextStyle(fontSize: kTamanoCaption, color: kColorTextoSecund),
              ),
              const SizedBox(height: kPaddingSmall),

              // Clases del modelo
              ...List.generate(clases.length, (i) {
                final c      = colores[i] ?? kColorPrimario;
                final activo = seleccionado == i;
                return GestureDetector(
                  onTap: () => setS(() => seleccionado = i),
                  child: Container(
                    margin:  const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.symmetric(
                        horizontal: kPaddingSmall, vertical: 6),
                    decoration: BoxDecoration(
                      color: activo ? c.withAlpha(30) : Colors.transparent,
                      borderRadius: BorderRadius.circular(kRadioBorde),
                      border: Border.all(
                        color: activo ? c : kColorNeutroBorde,
                        width: activo ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          activo
                              ? Icons.radio_button_checked
                              : Icons.radio_button_unchecked,
                          color: activo ? c : kColorTextoSecund,
                          size: 18,
                        ),
                        const SizedBox(width: kPaddingSmall),
                        Text(
                          clases[i],
                          style: TextStyle(
                            color:      activo ? c : kColorTexto,
                            fontWeight: activo ? FontWeight.bold : FontWeight.normal,
                            fontSize:   kTamanoCuerpo,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),

              // Separador + opción negativa
              const Divider(height: 16),
              GestureDetector(
                onTap: () => setS(() => seleccionado = -1),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: kPaddingSmall, vertical: 6),
                  decoration: BoxDecoration(
                    color: seleccionado == -1
                        ? kColorError.withAlpha(20)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(kRadioBorde),
                    border: Border.all(
                      color: seleccionado == -1 ? kColorError : kColorNeutroBorde,
                      width: seleccionado == -1 ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        seleccionado == -1
                            ? Icons.radio_button_checked
                            : Icons.radio_button_unchecked,
                        color: seleccionado == -1 ? kColorError : kColorTextoSecund,
                        size: 18,
                      ),
                      const SizedBox(width: kPaddingSmall),
                      Text(
                        'No es cacao',
                        style: TextStyle(
                          color:      seleccionado == -1 ? kColorError : kColorTextoSecund,
                          fontWeight: seleccionado == -1 ? FontWeight.bold : FontWeight.normal,
                          fontSize:   kTamanoCuerpo,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('Cancelar',
                  style: TextStyle(color: kColorTextoSecund)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, seleccionado),
              child: const Text('Confirmar'),
            ),
          ],
        ),
      ),
    );

    if (claseCorregida == null || !mounted) return;

    // "No es cacao" → guardar como negativo para futuros entrenamientos
    if (claseCorregida == -1) {
      await widget.sqlite.guardarNegativo(widget.imagen.path);
    } else {
      final etiquetaCorregida = clases[claseCorregida];
      await widget.sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath:      widget.imagen.path,
        tipoModelo:      tipoModelo,
        claseModelo:     det.claseId,
        confianza:       det.confianza,
        claseConfirmada: claseCorregida,
        fueCorregida:    claseCorregida != det.claseId,
        timestamp:       DateTime.now().millisecondsSinceEpoch,
      ));
      // Actualiza el historial con la clase confirmada por el usuario
      await widget.sqlite.guardarEnHistorial(HistorialRegistro(
        imagenPath: widget.imagen.path,
        etiqueta:   etiquetaCorregida,
        confianza:  det.confianza,
        estaSana:   tipoModelo == 'madurez' || etiquetaCorregida == 'Sana',
        timestamp:  DateTime.now().millisecondsSinceEpoch,
      ));
    }

    // Sincronizar inmediatamente con Supabase
    FirebaseSyncService(widget.sqlite).sincronizar();

    if (!mounted) return;
    setState(() => _corregido = true);
    final msg = claseCorregida == -1
        ? 'Imagen guardada como fondo. ¡Gracias por mejorar el modelo!'
        : 'Corrección guardada. ¡Gracias por mejorar el modelo!';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _guardarEnHistorial() async {
    if (_guardado || _guardando) return;
    setState(() => _guardando = true);

    // La etiqueta principal es la del resultado que se muestra al usuario
    final det = widget.estaSana ? widget.detMadurez : widget.detEnfermedad;
    final etiqueta  = det?.claseNombre ?? 'Sin detección';
    final confianza = det?.confianza   ?? 0.0;

    await widget.sqlite.guardarEnHistorial(HistorialRegistro(
      imagenPath: widget.imagen.path,
      etiqueta:   etiqueta,
      confianza:  confianza,
      estaSana:   widget.estaSana,
      timestamp:  DateTime.now().millisecondsSinceEpoch,
    ));

    if (!mounted) return;
    setState(() { _guardado = true; _guardando = false; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Guardado en historial')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Resultado del Análisis'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(kPaddingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ── Imagen analizada ──────────────────────────────────────────
            ClipRRect(
              borderRadius: BorderRadius.circular(kRadioBorde),
              child: Image.file(
                widget.imagen,
                width:  double.infinity,
                height: 260,
                fit:    BoxFit.cover,
              ),
            ),

            const SizedBox(height: kPaddingLarge),

            // ── Resultado principal ───────────────────────────────────────
            // Escenario 1: mazorca sana → mostrar madurez
            if (widget.estaSana) ...[
              const Text(
                'Estado de madurez',
                style: TextStyle(
                  fontSize:   kTamanoSubtitulo,
                  fontWeight: FontWeight.bold,
                  color:      kColorTexto,
                ),
              ),
              const SizedBox(height: kPaddingSmall),
              widget.detMadurez != null
                  ? _tarjetaDeteccion(widget.detMadurez!, kColoresMadurez)
                  : _tarjetaSinDeteccion('No se pudo determinar el estado de madurez'),
              const SizedBox(height: kPaddingLarge),
              _notaInformativa('La mazorca parece sana. Se analizó su estado de madurez.'),

            // Escenario 3: enfermedad detectada o inconcluso
            ] else ...[
              const Text(
                'Resultado del análisis',
                style: TextStyle(
                  fontSize:   kTamanoSubtitulo,
                  fontWeight: FontWeight.bold,
                  color:      kColorTexto,
                ),
              ),
              const SizedBox(height: kPaddingSmall),
              widget.detEnfermedad != null
                  ? _tarjetaDeteccion(widget.detEnfermedad!, kColoresEnfermedad)
                  : _tarjetaInconclusa(),
              if (widget.detEnfermedad != null) ...[
                const SizedBox(height: kPaddingLarge),
                _notaInformativa('Se detectó una posible enfermedad. Consulta con un agrónomo para confirmar.'),
              ],
            ],

            const SizedBox(height: kPaddingLarge),

            // ── Botones ───────────────────────────────────────────────────
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _guardado ? null : _guardarEnHistorial,
                icon: _guardando
                    ? const SizedBox(
                        width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.save_outlined),
                label: Text(_guardado ? 'Guardado' : 'Guardar en Historial'),
              ),
            ),

            const SizedBox(height: kPaddingSmall),

            // Botón de corrección — solo cuando hay una detección real que corregir
            if ((widget.estaSana && widget.detMadurez != null) ||
                (!widget.estaSana && widget.detEnfermedad != null))
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: _corregido ? null : _corregir,
                  icon:  const Icon(Icons.edit_outlined),
                  label: Text(_corregido ? 'Corrección enviada' : 'Corregir resultado'),
                  style: TextButton.styleFrom(
                    foregroundColor: kColorSecundario,
                  ),
                ),
              ),

            const SizedBox(height: kPaddingSmall),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon:  const Icon(Icons.arrow_back),
                label: const Text('Nueva Detección'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: kColorPrimario,
                  side: const BorderSide(color: kColorPrimario),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Widgets auxiliares ──────────────────────────────────────────────────────

  /// Tarjeta cuando no hay detección
  Widget _notaInformativa(String texto) {
    return Container(
      padding: const EdgeInsets.all(kPaddingMedium),
      decoration: BoxDecoration(
        color:        kColorInfoFondo,
        borderRadius: BorderRadius.circular(kRadioBorde),
        border:       Border.all(color: kColorInfoBorde),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: kColorInfo, size: 20),
          const SizedBox(width: kPaddingSmall),
          Expanded(
            child: Text(
              texto,
              style: const TextStyle(fontSize: kTamanoCaption, color: kColorInfo),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tarjetaInconclusa() {
    return Container(
      width:   double.infinity,
      padding: const EdgeInsets.all(kPaddingMedium),
      decoration: BoxDecoration(
        color:        kColorError.withAlpha(15),
        borderRadius: BorderRadius.circular(kRadioBorde),
        border:       Border.all(color: kColorError.withAlpha(80)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.warning_amber_rounded, color: kColorError),
          const SizedBox(width: kPaddingSmall),
          const Expanded(
            child: Text(
              'No fue posible procesar la imagen con suficiente confianza.\n'
              'Intenta con mejor iluminación o acércate más a la mazorca.',
              style: TextStyle(color: kColorError),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tarjetaSinDeteccion(String mensaje) {
    return Container(
      width:   double.infinity,
      padding: const EdgeInsets.all(kPaddingMedium),
      decoration: BoxDecoration(
        color:        kColorNeutroFondo,
        borderRadius: BorderRadius.circular(kRadioBorde),
        border:       Border.all(color: kColorNeutroBorde),
      ),
      child: Row(
        children: [
          const Icon(Icons.help_outline, color: kColorTextoSecund),
          const SizedBox(width: kPaddingSmall),
          Expanded(
            child: Text(
              mensaje,
              style: const TextStyle(color: kColorTextoSecund),
            ),
          ),
        ],
      ),
    );
  }

  /// Tarjeta con el resultado de una detección
  Widget _tarjetaDeteccion(DeteccionResultado det, Map<int, Color> colores) {
    final color      = colores[det.claseId] ?? kColorPrimario;
    final porcentaje = (det.confianza * 100).toStringAsFixed(1);

    return Container(
      padding: const EdgeInsets.all(kPaddingMedium),
      decoration: BoxDecoration(
        color:        color.withAlpha(20),
        borderRadius: BorderRadius.circular(kRadioBorde),
        border:       Border.all(color: color.withAlpha(100)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Nombre de la clase
          Row(
            children: [
              Container(
                width: 14, height: 14,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              ),
              const SizedBox(width: kPaddingSmall),
              Text(
                det.claseNombre,
                style: TextStyle(
                  fontSize:   kTamanoSubtitulo,
                  fontWeight: FontWeight.bold,
                  color:      color,
                ),
              ),
            ],
          ),

          const SizedBox(height: kPaddingSmall),

          // Barra de confianza
          Row(
            children: [
              Expanded(
                child: LinearProgressIndicator(
                  value:           det.confianza,
                  backgroundColor: color.withAlpha(30),
                  valueColor:      AlwaysStoppedAnimation<Color>(color),
                  minHeight:       8,
                  borderRadius:    BorderRadius.circular(4),
                ),
              ),
              const SizedBox(width: kPaddingSmall),
              Text(
                '$porcentaje%',
                style: TextStyle(
                  fontSize:   kTamanoCuerpo,
                  fontWeight: FontWeight.bold,
                  color:      color,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
