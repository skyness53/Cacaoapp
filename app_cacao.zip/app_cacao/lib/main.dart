import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/constants/app_theme.dart';
import 'core/constants/supabase_config.dart';
import 'features/camera/camera_screen.dart';
import 'features/historial/historial_screen.dart';

// =============================================================================
// PUNTO DE ENTRADA DE LA APP
// =============================================================================
// Para agregar una nueva pantalla al menú inferior:
//   1. Crea la pantalla en features/<nombre>/<nombre>_screen.dart
//   2. Agrega un BottomNavigationBarItem en la lista de items abajo
//   3. Agrega la pantalla en la lista _pantallas
// =============================================================================

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url:    kSupabaseUrl,
    anonKey: kSupabaseAnonKey,
  );
  runApp(const AppCacao());
}

class AppCacao extends StatelessWidget {
  const AppCacao({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:                      'App Cacao',
      debugShowCheckedModeBanner: false,
      theme:                      AppTheme.tema, // Tema definido en app_theme.dart
      home:                       const NavPrincipal(),
    );
  }
}

// ─── Navegación principal con barra inferior ─────────────────────────────────

class NavPrincipal extends StatefulWidget {
  const NavPrincipal({super.key});

  @override
  State<NavPrincipal> createState() => _NavPrincipalState();
}

class _NavPrincipalState extends State<NavPrincipal> {
  int _indiceActual    = 0;
  int _historialVersion = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _indiceActual,
        children: [
          const CameraScreen(),
          // La clave cambia cada vez que el usuario entra al tab,
          // forzando que HistorialScreen recargue sus datos.
          HistorialScreen(key: ValueKey(_historialVersion)),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex:        _indiceActual,
        onTap: (i) => setState(() {
          if (i == 1 && _indiceActual != 1) _historialVersion++;
          _indiceActual = i;
        }),
        selectedItemColor:   kColorPrimario,
        unselectedItemColor: kColorTextoSecund,
        items: const [
          BottomNavigationBarItem(
            icon:       Icon(Icons.camera_alt_outlined),
            activeIcon: Icon(Icons.camera_alt),
            label:      'Detectar',
          ),
          BottomNavigationBarItem(
            icon:       Icon(Icons.history_outlined),
            activeIcon: Icon(Icons.history),
            label:      'Historial',
          ),
          // Para agregar un nuevo tab: copiar este bloque y agregar la
          // pantalla correspondiente en la lista _pantallas de arriba
        ],
      ),
    );
  }
}
