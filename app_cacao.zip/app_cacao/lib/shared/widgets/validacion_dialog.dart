import 'package:flutter/material.dart';
import '../../core/constants/app_theme.dart';
import '../../core/services/tflite_service.dart';

// =============================================================================
// DIÁLOGO DE VALIDACIÓN — ACTIVE LEARNING
// =============================================================================
// Se muestra cuando la confianza está entre 65% y 83%.
// El usuario puede confirmar o corregir la detección del modelo.
// La respuesta se guarda en la base de datos para reentrenamiento futuro.
//
// Retorna un ValidacionResultado con:
//   - claseConfirmada: la clase que el usuario aceptó o corrigió
//   - fueCorregido: true si el usuario cambió la clase del modelo
// =============================================================================

class ValidacionResultado {
  final int  claseConfirmada; // Clase final (puede ser la del modelo o la corregida)
  final bool fueCorregido;    // true = el usuario cambió la clase

  const ValidacionResultado({
    required this.claseConfirmada,
    required this.fueCorregido,
  });
}

class ValidacionDialog extends StatefulWidget {
  final DeteccionResultado deteccion;    // Resultado del modelo
  final List<String>       opciones;     // Nombres de todas las clases posibles
  final Map<int, Color>    colores;      // Colores por clase
  final String             tipoModelo;  // "enfermedades" o "madurez"

  const ValidacionDialog({
    super.key,
    required this.deteccion,
    required this.opciones,
    required this.colores,
    required this.tipoModelo,
  });

  @override
  State<ValidacionDialog> createState() => _ValidacionDialogState();
}

class _ValidacionDialogState extends State<ValidacionDialog> {
  late int _claseSeleccionada;

  @override
  void initState() {
    super.initState();
    // Inicia con la clase que detectó el modelo
    _claseSeleccionada = widget.deteccion.claseId;
  }

  @override
  Widget build(BuildContext context) {
    final color      = widget.colores[widget.deteccion.claseId] ?? kColorPrimario;
    final porcentaje = (widget.deteccion.confianza * 100).toStringAsFixed(1);

    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kRadioBordeLarge),
      ),
      title: const Row(
        children: [
          Icon(Icons.help_outline, color: kColorSecundario),
          SizedBox(width: kPaddingSmall),
          Text(
            '¿Es correcto?',
            style: TextStyle(fontSize: kTamanoSubtitulo),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // Resultado del modelo con confianza
          Text(
            'El modelo detectó:',
            style: TextStyle(fontSize: kTamanoCaption, color: kColorTextoSecund),
          ),
          const SizedBox(height: kPaddingSmall),
          Container(
            padding: const EdgeInsets.all(kPaddingSmall),
            decoration: BoxDecoration(
              color:        color.withAlpha(20),
              borderRadius: BorderRadius.circular(kRadioBorde),
              border:       Border.all(color: color.withAlpha(80)),
            ),
            child: Row(
              children: [
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                ),
                const SizedBox(width: kPaddingSmall),
                Text(
                  widget.deteccion.claseNombre,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color:      color,
                    fontSize:   kTamanoCuerpo,
                  ),
                ),
                const Spacer(),
                Text(
                  '$porcentaje%',
                  style: TextStyle(
                    color:    color,
                    fontSize: kTamanoCaption,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: kPaddingMedium),

          // Aviso de confianza media
          Container(
            padding: const EdgeInsets.all(kPaddingSmall),
            decoration: BoxDecoration(
              color:        kColorAdvertenciaFondo,
              borderRadius: BorderRadius.circular(kRadioBorde),
            ),
            child: Row(
              children: [
                const Icon(Icons.warning_amber_outlined,
                    color: kColorAdvertencia, size: 16),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    'Confianza media. Por favor confirma o corrige.',
                    style: TextStyle(
                      fontSize: kTamanoCaption,
                      color:    kColorAdvertencia,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: kPaddingMedium),

          // Selector de clase correcta
          Text(
            '¿Cuál es la clase correcta?',
            style: TextStyle(fontSize: kTamanoCaption, color: kColorTextoSecund),
          ),
          const SizedBox(height: kPaddingSmall),

          // Lista de opciones
          ...List.generate(widget.opciones.length, (i) {
            final colorOpcion = widget.colores[i] ?? kColorPrimario;
            final seleccionado = _claseSeleccionada == i;
            return GestureDetector(
              onTap: () => setState(() => _claseSeleccionada = i),
              child: Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(
                  horizontal: kPaddingSmall,
                  vertical:   6,
                ),
                decoration: BoxDecoration(
                  color: seleccionado
                      ? colorOpcion.withAlpha(30)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(kRadioBorde),
                  border: Border.all(
                    color: seleccionado ? colorOpcion : kColorNeutroBorde,
                    width: seleccionado ? 2 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      seleccionado
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      color: seleccionado ? colorOpcion : kColorTextoSecund,
                      size: 18,
                    ),
                    const SizedBox(width: kPaddingSmall),
                    Text(
                      widget.opciones[i],
                      style: TextStyle(
                        color:      seleccionado ? colorOpcion : kColorTexto,
                        fontWeight: seleccionado ? FontWeight.bold : FontWeight.normal,
                        fontSize:   kTamanoCuerpo,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),

          // Separador + opción negativa
          const Divider(height: 16),
          GestureDetector(
            onTap: () => setState(() => _claseSeleccionada = -1),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: kPaddingSmall, vertical: 6),
              decoration: BoxDecoration(
                color: _claseSeleccionada == -1
                    ? kColorError.withAlpha(20)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(kRadioBorde),
                border: Border.all(
                  color: _claseSeleccionada == -1 ? kColorError : kColorNeutroBorde,
                  width: _claseSeleccionada == -1 ? 2 : 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _claseSeleccionada == -1
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                    color: _claseSeleccionada == -1 ? kColorError : kColorTextoSecund,
                    size: 18,
                  ),
                  const SizedBox(width: kPaddingSmall),
                  Text(
                    'No es cacao',
                    style: TextStyle(
                      color:      _claseSeleccionada == -1 ? kColorError : kColorTextoSecund,
                      fontWeight: _claseSeleccionada == -1 ? FontWeight.bold : FontWeight.normal,
                      fontSize:   kTamanoCuerpo,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      actions: [
        // Botón descartar
        TextButton(
          onPressed: () => Navigator.pop(context, null),
          child: const Text(
            'Descartar',
            style: TextStyle(color: kColorTextoSecund),
          ),
        ),

        // Botón confirmar
        ElevatedButton(
          onPressed: () {
            Navigator.pop(
              context,
              ValidacionResultado(
                claseConfirmada: _claseSeleccionada,
                fueCorregido:    _claseSeleccionada != widget.deteccion.claseId,
              ),
            );
          },
          child: const Text('Confirmar'),
        ),
      ],
    );
  }
}
