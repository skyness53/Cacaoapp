import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart';
import 'package:app_cacao/core/services/sqlite_service.dart';
import 'package:app_cacao/features/historial/historial_screen.dart';

// Pruebas I1–I4 — Integración SQLiteService ↔ HistorialScreen
// Verifica que la capa de base de datos y la interfaz de usuario
// intercambian datos correctamente sin depender de un dispositivo físico.
//
// Nota técnica: se usa databaseFactoryFfiNoIsolate para que las operaciones
// SQLite corran en el hilo principal, compatible con el entorno de pruebas
// de Flutter (FakeAsync). Cada archivo usa un directorio temporal propio
// para evitar conflictos de archivo cuando flutter test corre en paralelo.
//
// Ejecutar con: flutter test test/integracion/integracion_test.dart

Directory? _tempDir;

void main() {
  setUpAll(() async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfiNoIsolate;
    _tempDir = Directory.systemTemp.createTempSync('sqflite_int_');
    await databaseFactoryFfiNoIsolate.setDatabasesPath(_tempDir!.path);
  });

  tearDownAll(() async {
    try {
      await databaseFactoryFfiNoIsolate.deleteDatabase(
        join(_tempDir!.path, 'app_cacao.db'),
      );
    } catch (_) {}
    _tempDir?.deleteSync(recursive: true);
  });

  Future<void> limpiarDB() async {
    await databaseFactoryFfiNoIsolate.deleteDatabase(
      join(_tempDir!.path, 'app_cacao.db'),
    );
  }

  // setUp limpia la DB antes de cada test para garantizar estado aislado.
  setUp(limpiarDB);

  // ── Prueba I1 ────────────────────────────────────────────────────────────────
  // Verifica que la pantalla de historial muestra el estado vacío cuando la
  // tabla historial en SQLite no tiene registros.
  testWidgets('I1: HistorialScreen muestra estado vacío cuando SQLite está vacío',
      (tester) async {
    await tester.runAsync(() async {
      await tester.pumpWidget(const MaterialApp(home: HistorialScreen()));
      await Future.delayed(const Duration(milliseconds: 500));
    });
    await tester.pump();

    expect(find.text('Sin detecciones guardadas'), findsOneWidget);
    expect(find.text('Analiza una mazorca y guarda el resultado'), findsOneWidget);
  });

  // ── Prueba I2 ────────────────────────────────────────────────────────────────
  // Verifica que un registro insertado via SQLiteService aparece en la UI de
  // HistorialScreen (integración DB → vista).
  testWidgets('I2: HistorialScreen muestra etiqueta y confianza del registro guardado',
      (tester) async {
    await tester.runAsync(() async {
      final sqlite = SQLiteService();
      await sqlite.inicializar();
      await sqlite.guardarEnHistorial(HistorialRegistro(
        imagenPath: '/img/test.jpg',
        etiqueta:   'Monilia',
        confianza:  0.88,
        estaSana:   false,
        timestamp:  1700000000010,
      ));
      sqlite.dispose();

      await tester.pumpWidget(const MaterialApp(home: HistorialScreen()));
      await Future.delayed(const Duration(milliseconds: 500));
    });
    await tester.pump();

    expect(find.text('Monilia'), findsOneWidget);
    expect(find.text('88.0%'), findsOneWidget);
  });

  // ── Prueba I3 ────────────────────────────────────────────────────────────────
  // Verifica que el gesto de deslizar (Dismissible) elimina el registro de la
  // vista y muestra el estado vacío, confirmando que la acción se propaga a SQLite.
  testWidgets('I3: deslizar tarjeta elimina el registro y muestra estado vacío',
      (tester) async {
    await tester.runAsync(() async {
      final sqlite = SQLiteService();
      await sqlite.inicializar();
      await sqlite.guardarEnHistorial(HistorialRegistro(
        imagenPath: '/img/del.jpg',
        etiqueta:   'Sana',
        confianza:  0.95,
        estaSana:   true,
        timestamp:  1700000000020,
      ));
      sqlite.dispose();

      await tester.pumpWidget(const MaterialApp(home: HistorialScreen()));
      await Future.delayed(const Duration(milliseconds: 500));
    });
    await tester.pump();

    expect(find.text('Sana'), findsOneWidget);

    await tester.drag(find.byType(Dismissible), const Offset(-500, 0));
    await tester.pumpAndSettle();

    expect(find.text('Sana'), findsNothing);
    expect(find.text('Sin detecciones guardadas'), findsOneWidget);
  });

  // ── Prueba I4 ────────────────────────────────────────────────────────────────
  // Verifica que el contador en el AppBar refleja el número real de registros
  // que hay en la tabla historial de SQLite.
  testWidgets('I4: contador en AppBar refleja la cantidad de registros en SQLite',
      (tester) async {
    await tester.runAsync(() async {
      final sqlite = SQLiteService();
      await sqlite.inicializar();
      for (int i = 0; i < 3; i++) {
        await sqlite.guardarEnHistorial(HistorialRegistro(
          imagenPath: '/img/cnt_$i.jpg',
          etiqueta:   'Maduro',
          confianza:  0.80,
          estaSana:   true,
          timestamp:  1700000000030 + i,
        ));
      }
      sqlite.dispose();

      await tester.pumpWidget(const MaterialApp(home: HistorialScreen()));
      await Future.delayed(const Duration(milliseconds: 500));
    });
    await tester.pump();

    expect(find.text('3/20'), findsOneWidget);
  });
}
