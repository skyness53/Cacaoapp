import 'package:flutter_test/flutter_test.dart';
import 'package:app_cacao/core/services/sqlite_service.dart';

void main() {
  group('DeteccionRegistro', () {

    // Prueba 1 
    test('toMap serializa todos los campos correctamente', () {
      final registro = DeteccionRegistro(
        imagenPath:      '/ruta/imagen.jpg',
        tipoModelo:      'enfermedades',
        claseModelo:     3,
        confianza:       0.91,
        claseConfirmada: 3,
        fueCorregida:    false,
        timestamp:       1700000000000,
        sincronizada:    false,
      );

      final mapa = registro.toMap();

      expect(mapa['imagen_path'],       '/ruta/imagen.jpg');
      expect(mapa['tipo_modelo'],       'enfermedades');
      expect(mapa['clase_modelo'],      3);
      expect(mapa['confianza'],         0.91);
      expect(mapa['clase_confirmada'],  3);
      expect(mapa['fue_corregida'],     0);
      expect(mapa['timestamp'],         1700000000000);
      expect(mapa['sincronizada'],      0);
    });

    // ── Prueba 2 ────────────────────────────────────────────────────────────────
    test('fromMap reconstruye el objeto correctamente', () {
      final mapa = {
        'id':              1,
        'imagen_path':     '/ruta/imagen.jpg',
        'tipo_modelo':     'madurez',
        'clase_modelo':    2,
        'confianza':       0.75,
        'clase_confirmada': 0,
        'fue_corregida':   1,
        'timestamp':       1700000000000,
        'sincronizada':    1,
      };

      final registro = DeteccionRegistro.fromMap(mapa);

      expect(registro.id,              1);
      expect(registro.tipoModelo,      'madurez');
      expect(registro.claseModelo,     2);
      expect(registro.confianza,       0.75);
      expect(registro.claseConfirmada, 0);
      expect(registro.fueCorregida,    true);
      expect(registro.sincronizada,    true);
    });

    // ── Prueba 3 ────────────────────────────────────────────────────────────────
    test('toMap convierte fueCorregida bool → entero (0 o 1)', () {
      final conCorreccion = DeteccionRegistro(
        imagenPath: '/img.jpg', tipoModelo: 'enfermedades',
        claseModelo: 1, confianza: 0.70, claseConfirmada: 2,
        fueCorregida: true, timestamp: 0,
      );
      final sinCorreccion = DeteccionRegistro(
        imagenPath: '/img.jpg', tipoModelo: 'enfermedades',
        claseModelo: 1, confianza: 0.70, claseConfirmada: 1,
        fueCorregida: false, timestamp: 0,
      );

      expect(conCorreccion.toMap()['fue_corregida'], 1);
      expect(sinCorreccion.toMap()['fue_corregida'], 0);
    });

    // ── Prueba 4 ────────────────────────────────────────────────────────────────
    test('registro negativo tiene claseModelo y claseConfirmada en -1', () {
      final negativo = DeteccionRegistro(
        imagenPath:      '/negativos/neg_123.jpg',
        tipoModelo:      'negativo',
        claseModelo:     -1,
        confianza:       0.0,
        claseConfirmada: -1,
        fueCorregida:    true,
        timestamp:       1700000000000,
      );

      expect(negativo.claseModelo,     -1);
      expect(negativo.claseConfirmada, -1);
      expect(negativo.tipoModelo,      'negativo');
      expect(negativo.confianza,       0.0);
    });

  });
}
