import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart';
import 'package:app_cacao/core/services/sqlite_service.dart';

// Pruebas 10–13 — SQLiteService con base de datos en memoria (sqflite_ffi)
// Cada archivo de test usa un directorio temporal propio para evitar conflictos
// cuando varios archivos corren en paralelo (aislados distintos de flutter test).
// Ejecutar con: flutter test test/unit/sqlite_service_test.dart

Directory? _tempDir;

void main() {
  setUpAll(() async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    _tempDir = Directory.systemTemp.createTempSync('sqflite_unit_');
    await databaseFactoryFfi.setDatabasesPath(_tempDir!.path);
  });

  tearDownAll(() {
    _tempDir?.deleteSync(recursive: true);
  });

  late SQLiteService sqlite;

  setUp(() async {
    sqlite = SQLiteService();
    await sqlite.inicializar();
  });

  tearDown(() async {
    sqlite.dispose();
    await databaseFactoryFfi.deleteDatabase(join(_tempDir!.path, 'app_cacao.db'));
  });

  group('SQLiteService — base de datos local', () {

    // ── Prueba 10 ────────────────────────────────────────────────────────────────
    // Verifica que el pipeline de Active Learning registra correctamente los
    // negativos (imágenes sin mazorca) con clases centinela -1.
    test('P10: guardarDeteccion almacena registro negativo con clases en -1', () async {
      final id = await sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath:      '/img/neg_001.jpg',
        tipoModelo:      'negativo',
        claseModelo:     -1,
        confianza:       0.0,
        claseConfirmada: -1,
        fueCorregida:    true,
        timestamp:       1700000000000,
      ));

      final todas = await sqlite.obtenerTodas();
      final guardado = todas.firstWhere((r) => r.id == id);

      expect(guardado.tipoModelo,      'negativo');
      expect(guardado.claseModelo,     -1);
      expect(guardado.claseConfirmada, -1);
      expect(guardado.confianza,       0.0);
    });

    // ── Prueba 11 ────────────────────────────────────────────────────────────────
    // Verifica que la consulta de pendientes filtra correctamente los registros
    // que ya fueron sincronizados con Supabase.
    test('P11: obtenerPendientesSincronizacion excluye registros ya sincronizados', () async {
      await sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath: '/img/a.jpg', tipoModelo: 'enfermedades',
        claseModelo: 1, confianza: 0.90, claseConfirmada: 1,
        fueCorregida: false, timestamp: 1700000000001, sincronizada: false,
      ));
      await sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath: '/img/b.jpg', tipoModelo: 'madurez',
        claseModelo: 2, confianza: 0.85, claseConfirmada: 2,
        fueCorregida: false, timestamp: 1700000000002, sincronizada: true,
      ));

      final pendientes = await sqlite.obtenerPendientesSincronizacion();

      expect(pendientes.length, 1);
      expect(pendientes.first.imagenPath, '/img/a.jpg');
      expect(pendientes.first.sincronizada, false);
    });

    // ── Prueba 12 ────────────────────────────────────────────────────────────────
    // Verifica que marcarSincronizada actualiza el campo en la base de datos y
    // el registro desaparece de los pendientes.
    test('P12: marcarSincronizada elimina el registro de la cola de pendientes', () async {
      final id = await sqlite.guardarDeteccion(DeteccionRegistro(
        imagenPath: '/img/c.jpg', tipoModelo: 'enfermedades',
        claseModelo: 0, confianza: 0.87, claseConfirmada: 0,
        fueCorregida: false, timestamp: 1700000000003,
      ));

      var pendientes = await sqlite.obtenerPendientesSincronizacion();
      expect(pendientes.any((r) => r.id == id), true);

      await sqlite.marcarSincronizada(id);

      pendientes = await sqlite.obtenerPendientesSincronizacion();
      expect(pendientes.any((r) => r.id == id), false);
    });

    // ── Prueba 13 ────────────────────────────────────────────────────────────────
    // Verifica la política de retención del historial: al superar 20 entradas
    // se elimina automáticamente la más antigua (por timestamp).
    test('P13: insertar 21 registros mantiene solo los 20 más recientes en historial', () async {
      for (int i = 0; i < 21; i++) {
        await sqlite.guardarEnHistorial(HistorialRegistro(
          imagenPath: '/img/hist_$i.jpg',
          etiqueta:   'Sana',
          confianza:  0.90,
          estaSana:   true,
          timestamp:  1700000000000 + i,
        ));
      }

      final historial = await sqlite.obtenerHistorial();

      expect(historial.length, 20,
          reason: 'El historial debe tener exactamente 20 registros');
      expect(historial.any((r) => r.imagenPath == '/img/hist_0.jpg'), false,
          reason: 'El registro más antiguo (hist_0) debe haberse eliminado');
      expect(historial.any((r) => r.imagenPath == '/img/hist_20.jpg'), true,
          reason: 'El registro más reciente (hist_20) debe estar presente');
    });

  });
}
