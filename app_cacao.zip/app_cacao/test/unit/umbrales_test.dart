import 'package:flutter_test/flutter_test.dart';
import 'package:app_cacao/core/constants/app_constants.dart';

// Replica la lógica de umbrales de camera_screen para poder probarla de forma
// aislada sin depender de la UI ni del modelo TFLite.
enum _ResultadoUmbral { descartado, inconcluso, requiereValidacion, autoLabel }

_ResultadoUmbral _evaluarConfianza(double confianza) {
  if (confianza < kUmbralDeteccion)  return _ResultadoUmbral.descartado;
  if (confianza < kUmbralValidacion) return _ResultadoUmbral.inconcluso;
  if (confianza < kUmbralAutoLabel)  return _ResultadoUmbral.requiereValidacion;
  return _ResultadoUmbral.autoLabel;
}

void main() {
  group('Lógica de umbrales de confianza', () {

    // ── Prueba 5 ────────────────────────────────────────────────────────────────
    test('confianza por debajo de kUmbralDeteccion → descartado', () {
      expect(_evaluarConfianza(0.05),  _ResultadoUmbral.descartado);
      expect(_evaluarConfianza(0.14),  _ResultadoUmbral.descartado);
      expect(_evaluarConfianza(0.0),   _ResultadoUmbral.descartado);
    });

    // ── Prueba 6 ────────────────────────────────────────────────────────────────
    test('confianza entre kUmbralDeteccion y kUmbralValidacion → inconcluso', () {
      expect(_evaluarConfianza(0.15),  _ResultadoUmbral.inconcluso);
      expect(_evaluarConfianza(0.40),  _ResultadoUmbral.inconcluso);
      expect(_evaluarConfianza(0.64),  _ResultadoUmbral.inconcluso);
    });

    // ── Prueba 7 ────────────────────────────────────────────────────────────────
    test('confianza entre kUmbralValidacion y kUmbralAutoLabel → requiere validación', () {
      expect(_evaluarConfianza(0.65),  _ResultadoUmbral.requiereValidacion);
      expect(_evaluarConfianza(0.75),  _ResultadoUmbral.requiereValidacion);
      expect(_evaluarConfianza(0.82),  _ResultadoUmbral.requiereValidacion);
    });

    // ── Prueba 8 ────────────────────────────────────────────────────────────────
    test('confianza igual o mayor a kUmbralAutoLabel → auto-label', () {
      expect(_evaluarConfianza(0.83),  _ResultadoUmbral.autoLabel);
      expect(_evaluarConfianza(0.95),  _ResultadoUmbral.autoLabel);
      expect(_evaluarConfianza(1.0),   _ResultadoUmbral.autoLabel);
    });

    // ── Prueba 9 (límites exactos) ───────────────────────────────────────────────
    test('valores exactos en los límites de umbral se clasifican correctamente', () {
      expect(_evaluarConfianza(kUmbralDeteccion),  _ResultadoUmbral.inconcluso);
      expect(_evaluarConfianza(kUmbralValidacion), _ResultadoUmbral.requiereValidacion);
      expect(_evaluarConfianza(kUmbralAutoLabel),  _ResultadoUmbral.autoLabel);
    });

  });
}
