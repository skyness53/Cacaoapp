import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:app_cacao/shared/widgets/validacion_dialog.dart';
import 'package:app_cacao/core/services/tflite_service.dart';
import 'package:app_cacao/core/constants/app_constants.dart';
import 'package:app_cacao/core/constants/app_theme.dart';

// Detección de prueba: Monilia detectada con 72% de confianza
final _deteccionPrueba = DeteccionResultado(
  claseId:     3,
  claseNombre: 'Monilia',
  confianza:   0.72,
  bbox:        [0.1, 0.1, 0.9, 0.9],
);

Widget _construirDialogo() {
  return MaterialApp(
    home: Scaffold(
      body: Builder(
        builder: (context) => ValidacionDialog(
          deteccion:  _deteccionPrueba,
          opciones:   kClasesEnfermedades,
          colores:    kColoresEnfermedad,
          tipoModelo: 'enfermedades',
        ),
      ),
    ),
  );
}

void main() {
  group('ValidacionDialog', () {

    // ── Widget 1 ────────────────────────────────────────────────────────────────
    testWidgets('muestra todas las clases del modelo y la opción No es cacao',
        (WidgetTester tester) async {
      await tester.pumpWidget(_construirDialogo());

      // Las cuatro clases de enfermedades deben aparecer
      // (Monilia puede aparecer dos veces: en el resultado y en la lista)
      for (final clase in kClasesEnfermedades) {
        expect(find.text(clase), findsAtLeastNWidgets(1),
            reason: 'Debe mostrar la clase "$clase"');
      }

      // La opción negativa siempre debe estar presente
      expect(find.text('No es cacao'), findsOneWidget);

      // Los botones de acción deben estar visibles
      expect(find.text('Confirmar'), findsOneWidget);
      expect(find.text('Descartar'), findsOneWidget);
    });

    // ── Widget 2 ────────────────────────────────────────────────────────────────
    testWidgets('seleccionar No es cacao cambia la selección activa',
        (WidgetTester tester) async {
      await tester.pumpWidget(_construirDialogo());

      // Al inicio la clase del modelo (Monilia) debe estar visible
      expect(find.text('Monilia'), findsAtLeastNWidgets(1));

      // Toca la opción "No es cacao"
      await tester.tap(find.text('No es cacao'));
      await tester.pumpAndSettle();

      // Verificar que "No es cacao" ahora aparece en negrita (seleccionado)
      final textoNoEsCacao = tester.widget<Text>(find.text('No es cacao'));
      expect(
        textoNoEsCacao.style?.fontWeight,
        FontWeight.bold,
        reason: '"No es cacao" debe quedar en negrita al seleccionarse',
      );
    });

  });
}
